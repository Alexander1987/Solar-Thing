Solar Energy Harvester
